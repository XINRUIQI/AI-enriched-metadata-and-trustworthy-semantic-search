# Youth Offer for London — KS4 Destinations Starter Project

This folder contains a cleaned, streamlined version of the uploaded Key Stage 4 destinations data and a VS Code Python script for analysis/evaluation.

## Files

- `data/youth_offer_london_ks4_cleaned_streamlined.csv` — main cleaned wide dataset, one row per borough/provision/subgroup.
- `data/youth_offer_london_ks4_model_ready.csv` — smaller model-ready table with just the target proxy and key fields.
- `data/youth_offer_london_ks4_cleaned_long.csv` — long-format cleaned table, useful for auditing and extra charts.
- `src/youth_offer_analysis.py` — beginner-friendly analysis and evaluation script.
- `requirements.txt` — Python packages.

## How to run in VS Code

1. Open this folder in VS Code.
2. Create/activate a Python environment.
3. Install dependencies:

```bash
pip install -r requirements.txt
```

4. Run the script:

```bash
python src/youth_offer_analysis.py
```

5. Look in the `outputs/` folder for charts, metrics, ranked priority tables, and the vouching statement.

## Dataset caveat

This is not a direct youth unemployment dataset. It uses `risk_not_sustained_pct`, derived from **Not recorded as a sustained destination**, as a proxy for where targeted support may be needed.

## Cleaned data shape

- Cleaned long rows: 7,296
- Cleaned streamlined rows: 608
- Boroughs: 32
- Academic year: 2022/23
