
"""
Youth Offer for London: KS4 destinations analysis and model evaluation
======================================================================

This script is designed for VS Code.  It starts from a cleaned London KS4
Destinations dataset and produces:

1. Data quality checks
2. Policy analysis tables
3. Clear charts for presentation
4. A simple supervised-learning evaluation
5. Optional skore reports, if skore is installed

Important policy caveat
-----------------------
The uploaded KS4 destinations dataset is NOT a direct youth-unemployment or NEET
micro-dataset.  It is an aggregate destinations dataset.  In this script we use
"Not recorded as a sustained destination" as a proxy risk signal.  That means:

- Good use: identify borough/subgroup combinations that may need targeted support.
- Bad use: claim we have directly measured individual unemployment or directly
  predicted which young person is NEET.

The hackathon is about whether we can explain, evaluate, and vouch for the model,
so the comments below deliberately explain what each step is doing.
"""

from __future__ import annotations

from pathlib import Path
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import GroupShuffleSplit
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

warnings.filterwarnings("ignore", category=FutureWarning)

# -----------------------------------------------------------------------------
# 0. File paths
# -----------------------------------------------------------------------------
# The project ZIP contains the cleaned dataset in data/ already.
# Put this script in the project root and run:
#     python src/youth_offer_analysis.py

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_PATH = PROJECT_ROOT / "data" / "youth_offer_london_ks4_cleaned_streamlined.csv"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

RANDOM_STATE = 42


# -----------------------------------------------------------------------------
# 1. Load the cleaned dataset
# -----------------------------------------------------------------------------
def load_data(path: Path) -> pd.DataFrame:
    """Load the streamlined borough/subgroup-level data."""
    if not path.exists():
        raise FileNotFoundError(
            f"Could not find {path}. Make sure you run this from the project folder "
            "or update DATA_PATH at the top of the script."
        )

    df = pd.read_csv(path)

    # Keep numeric columns numeric.  errors='coerce' turns unexpected text into NaN,
    # which is safer than silently treating it as a real value.
    numeric_cols = [
        "cohort_count",
        "risk_not_sustained_pct",
        "estimated_not_sustained_count",
        "priority_score",
        "positive_sustained_destination_pct",
        "work_or_apprenticeship_pct",
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    return df


df = load_data(DATA_PATH)
print("Loaded cleaned dataset")
print(f"Rows: {df.shape[0]:,}, Columns: {df.shape[1]:,}")
print("Columns:", list(df.columns))


# -----------------------------------------------------------------------------
# 2. Basic data quality checks
# -----------------------------------------------------------------------------
# In a hackathon presentation, this is where you show that you did not blindly
# trust an AI-generated pipeline.

quality_summary = pd.DataFrame(
    {
        "column": df.columns,
        "missing_count": [df[c].isna().sum() for c in df.columns],
        "missing_pct": [100 * df[c].isna().mean() for c in df.columns],
        "unique_values": [df[c].nunique(dropna=True) for c in df.columns],
    }
).sort_values("missing_pct", ascending=False)
quality_summary.to_csv(OUTPUT_DIR / "01_data_quality_summary.csv", index=False)

print("\nData quality summary saved to outputs/01_data_quality_summary.csv")
print(quality_summary.head(10).to_string(index=False))

# Check the main target/proxy field.
print("\nRisk proxy distribution: risk_not_sustained_pct")
print(df["risk_not_sustained_pct"].describe().round(2).to_string())


# -----------------------------------------------------------------------------
# 3. Policy framing: what should we rank?
# -----------------------------------------------------------------------------
# The problem asks: "How might we tailor the Youth Offer for London to help the
# most young people into work or training?"
#
# Rate alone is not enough: a tiny group can have a very high percentage.
# Count alone is not enough: large boroughs dominate.
# So we keep three lenses:
#   - risk_not_sustained_pct: intensity of the issue
#   - estimated_not_sustained_count: approximate number of young people affected
#   - priority_score: a balanced score = rate * sqrt(cohort size)

priority_cols = [
    "borough",
    "provision_group",
    "subgroup_type",
    "subgroup",
    "cohort_count",
    "risk_not_sustained_pct",
    "estimated_not_sustained_count",
    "priority_score",
]
priority_table = df[priority_cols].sort_values("priority_score", ascending=False)
priority_table.to_csv(OUTPUT_DIR / "02_priority_table_all_groups.csv", index=False)

print("\nTop 15 borough/subgroup combinations by balanced priority score")
print(priority_table.head(15).to_string(index=False))


# -----------------------------------------------------------------------------
# 4. Visualise the structure and the policy signal
# -----------------------------------------------------------------------------
def save_barh(data: pd.DataFrame, x_col: str, y_col: str, title: str, filename: str, xlabel: str) -> None:
    """Simple horizontal bar chart helper."""
    fig, ax = plt.subplots(figsize=(10, max(5, 0.35 * len(data))))
    ax.barh(data[y_col], data[x_col])
    ax.set_title(title)
    ax.set_xlabel(xlabel)
    ax.invert_yaxis()
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / filename, dpi=160)
    plt.close(fig)


# 4a. Overall borough risk for the broad mainstream+special population.
all_pupils = df[
    (df["provision_group"] == "State-funded mainstream and special")
    & (df["subgroup_type"] == "all_pupils")
].copy()

borough_rate = all_pupils.sort_values("risk_not_sustained_pct", ascending=False)
save_barh(
    borough_rate,
    x_col="risk_not_sustained_pct",
    y_col="borough",
    title="Not recorded as sustained destination, by London borough",
    filename="03_borough_risk_rate.png",
    xlabel="Risk proxy (%)",
)

borough_count = all_pupils.sort_values("estimated_not_sustained_count", ascending=False)
save_barh(
    borough_count,
    x_col="estimated_not_sustained_count",
    y_col="borough",
    title="Estimated number not recorded as sustained destination, by London borough",
    filename="04_borough_estimated_count.png",
    xlabel="Estimated number of young people",
)

# 4b. Subgroup risk, weighted by cohort size across London boroughs.
# We exclude the all-pupils rows here so we can focus on equity-relevant groups.
subgroups = df[
    (df["provision_group"] == "State-funded mainstream and special")
    & (df["subgroup_type"] != "all_pupils")
].copy()
subgroups["weighted_risk_numerator"] = subgroups["risk_not_sustained_pct"] * subgroups["cohort_count"]
subgroup_summary = (
    subgroups.groupby(["subgroup_type", "subgroup"], as_index=False)
    .agg(
        cohort_count=("cohort_count", "sum"),
        weighted_risk_numerator=("weighted_risk_numerator", "sum"),
        estimated_not_sustained_count=("estimated_not_sustained_count", "sum"),
    )
)
subgroup_summary["weighted_risk_pct"] = (
    subgroup_summary["weighted_risk_numerator"] / subgroup_summary["cohort_count"]
)
subgroup_summary = subgroup_summary.sort_values("weighted_risk_pct", ascending=False)
subgroup_summary.to_csv(OUTPUT_DIR / "05_subgroup_weighted_risk_summary.csv", index=False)

# Make labels more presentation-friendly.
plot_subgroups = subgroup_summary.head(18).copy()
plot_subgroups["label"] = plot_subgroups["subgroup_type"] + ": " + plot_subgroups["subgroup"]
save_barh(
    plot_subgroups,
    x_col="weighted_risk_pct",
    y_col="label",
    title="Highest-risk London subgroups, weighted across boroughs",
    filename="06_subgroup_weighted_risk.png",
    xlabel="Weighted risk proxy (%)",
)

# 4c. Scatter: rate vs estimated count.
fig, ax = plt.subplots(figsize=(9, 6))
ax.scatter(all_pupils["risk_not_sustained_pct"], all_pupils["estimated_not_sustained_count"])
ax.set_title("Borough trade-off: risk rate vs number of young people affected")
ax.set_xlabel("Risk proxy (%)")
ax.set_ylabel("Estimated number not sustained")
# Label the highest-priority points so the plot is useful in a presentation.
for _, row in all_pupils.nlargest(8, "priority_score").iterrows():
    ax.annotate(row["borough"], (row["risk_not_sustained_pct"], row["estimated_not_sustained_count"]), fontsize=8)
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "07_rate_vs_count_scatter.png", dpi=160)
plt.close(fig)

print("\nCharts saved to outputs/03_... to outputs/07_...")


# -----------------------------------------------------------------------------
# 5. Supervised-learning setup
# -----------------------------------------------------------------------------
# We create a simple binary classification task:
#   y = 1 if a row is in the top quartile of risk_not_sustained_pct, else 0.
#
# Why top quartile?
#   - It is easy to explain in a 3-minute presentation.
#   - It focuses the model on prioritisation rather than pretending to predict exact unemployment.
#
# Leakage warning:
#   We DO NOT use other destination outcome percentages as features, because they are
#   mathematically related to the target.  That would create an impressive-looking but
#   untrustworthy model.

model_df = df.dropna(subset=["risk_not_sustained_pct", "cohort_count"]).copy()
threshold = model_df["risk_not_sustained_pct"].quantile(0.75)
model_df["high_risk"] = (model_df["risk_not_sustained_pct"] >= threshold).astype(int)

feature_cols = ["borough", "provision_group", "subgroup_type", "subgroup", "cohort_count"]
X = model_df[feature_cols]
y = model_df["high_risk"]
groups = model_df["borough"]

print("\nSupervised-learning target")
print(f"High-risk threshold: risk_not_sustained_pct >= {threshold:.2f}%")
print(y.value_counts().rename(index={0: "not_high_risk", 1: "high_risk"}).to_string())

# Use a group split by borough.  This is stricter than a random row split because
# it tests whether the model can generalise to boroughs it has not seen in training.
gss = GroupShuffleSplit(n_splits=50, test_size=0.25, random_state=RANDOM_STATE)
chosen_split = None
for train_idx, test_idx in gss.split(X, y, groups=groups):
    if y.iloc[train_idx].nunique() == 2 and y.iloc[test_idx].nunique() == 2:
        chosen_split = train_idx, test_idx
        break
if chosen_split is None:
    raise RuntimeError("Could not create a train/test split containing both classes.")

train_idx, test_idx = chosen_split
X_train, X_test = X.iloc[train_idx], X.iloc[test_idx]
y_train, y_test = y.iloc[train_idx], y.iloc[test_idx]

print("\nTrain/test split")
print(f"Training rows: {len(X_train):,}; Test rows: {len(X_test):,}")
print(f"Training boroughs: {X_train['borough'].nunique()}; Test boroughs: {X_test['borough'].nunique()}")


# -----------------------------------------------------------------------------
# 6. Baseline and main model
# -----------------------------------------------------------------------------
# Baseline: always predicts the most common class.  Any useful model should beat it.
baseline = DummyClassifier(strategy="most_frequent")

# Main model: one-hot encode text categories, scale cohort_count, then fit logistic regression.
# Logistic regression is easier to explain than a black-box model.
categorical_features = ["borough", "provision_group", "subgroup_type", "subgroup"]
numeric_features = ["cohort_count"]

preprocess = ColumnTransformer(
    transformers=[
        ("categorical", OneHotEncoder(handle_unknown="ignore"), categorical_features),
        ("numeric", StandardScaler(), numeric_features),
    ]
)

main_model = Pipeline(
    steps=[
        ("preprocess", preprocess),
        ("model", LogisticRegression(max_iter=1000, class_weight="balanced", random_state=RANDOM_STATE)),
    ]
)

baseline.fit(X_train, y_train)
main_model.fit(X_train, y_train)


# -----------------------------------------------------------------------------
# 7. Evaluation helpers
# -----------------------------------------------------------------------------
def evaluate_classifier(name: str, estimator, X_test: pd.DataFrame, y_test: pd.Series) -> dict:
    """Return common classification metrics for a fitted model."""
    pred = estimator.predict(X_test)
    metrics = {
        "model": name,
        "accuracy": accuracy_score(y_test, pred),
        "precision_high_risk": precision_score(y_test, pred, zero_division=0),
        "recall_high_risk": recall_score(y_test, pred, zero_division=0),
        "f1_high_risk": f1_score(y_test, pred, zero_division=0),
    }
    # ROC-AUC uses probabilities when available; not all classifiers have them.
    if hasattr(estimator, "predict_proba"):
        try:
            metrics["roc_auc"] = roc_auc_score(y_test, estimator.predict_proba(X_test)[:, 1])
        except Exception:
            metrics["roc_auc"] = np.nan
    else:
        metrics["roc_auc"] = np.nan
    return metrics


metrics = pd.DataFrame(
    [
        evaluate_classifier("Dummy baseline", baseline, X_test, y_test),
        evaluate_classifier("Logistic regression", main_model, X_test, y_test),
    ]
).round(3)
metrics.to_csv(OUTPUT_DIR / "08_model_metrics.csv", index=False)

print("\nModel metrics")
print(metrics.to_string(index=False))

# Detailed report for the main model.
y_pred = main_model.predict(X_test)
report_text = classification_report(y_test, y_pred, target_names=["not_high_risk", "high_risk"], zero_division=0)
(OUTPUT_DIR / "09_classification_report.txt").write_text(report_text)
print("\nClassification report for main model")
print(report_text)

cm = confusion_matrix(y_test, y_pred)
pd.DataFrame(
    cm,
    index=["actual_not_high_risk", "actual_high_risk"],
    columns=["pred_not_high_risk", "pred_high_risk"],
).to_csv(OUTPUT_DIR / "10_confusion_matrix.csv")

# Plot confusion matrix.
fig, ax = plt.subplots(figsize=(5, 4))
im = ax.imshow(cm)
ax.set_title("Confusion matrix: high-risk classification")
ax.set_xticks([0, 1], labels=["Pred not high", "Pred high"])
ax.set_yticks([0, 1], labels=["Actual not high", "Actual high"])
for i in range(cm.shape[0]):
    for j in range(cm.shape[1]):
        ax.text(j, i, cm[i, j], ha="center", va="center")
fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
fig.tight_layout()
fig.savefig(OUTPUT_DIR / "11_confusion_matrix.png", dpi=160)
plt.close(fig)


# -----------------------------------------------------------------------------
# 8. Explainability: permutation importance
# -----------------------------------------------------------------------------
# Permutation importance asks: if we randomly shuffle one feature, how much does
# performance drop? A larger drop means the model relied more on that feature.
# This gives a simple explainability table for the presentation.

perm = permutation_importance(
    main_model,
    X_test,
    y_test,
    n_repeats=30,
    random_state=RANDOM_STATE,
    scoring="f1",
)
importance = pd.DataFrame(
    {
        "feature": feature_cols,
        "importance_mean": perm.importances_mean,
        "importance_std": perm.importances_std,
    }
).sort_values("importance_mean", ascending=False)
importance.to_csv(OUTPUT_DIR / "12_permutation_importance.csv", index=False)

print("\nPermutation importance")
print(importance.to_string(index=False))


# -----------------------------------------------------------------------------
# 9. Optional skore report
# -----------------------------------------------------------------------------
# The hackathon encourages skore.  This block runs only if skore is installed.
# Install with:
#     pip install skore
#
# We keep this optional so the rest of the script still works on a fresh machine.

try:
    from skore import evaluate

    # skore's evaluate function creates an evaluation report object.  We use the
    # training set only here, because the held-out test evaluation above is our
    # final validation step.
    skore_report = evaluate(main_model, X_train, y_train, splitter=3)

    try:
        skore_metrics = skore_report.metrics.summarize().frame()
        skore_metrics.to_csv(OUTPUT_DIR / "13_skore_metrics_summary.csv", index=False)
    except Exception as exc:
        (OUTPUT_DIR / "13_skore_metrics_summary_error.txt").write_text(str(exc))

    try:
        skore_checks = skore_report.checks.summarize(fast_mode=True).frame()
        skore_checks.to_csv(OUTPUT_DIR / "14_skore_checks_summary.csv", index=False)
    except Exception as exc:
        (OUTPUT_DIR / "14_skore_checks_summary_error.txt").write_text(str(exc))

    print("\nskore report block ran. Check outputs/13_... and outputs/14_...")
except Exception as exc:
    print("\nskore is not installed or could not run. This is OK for development.")
    print("Install it with: pip install skore")
    print(f"Reason: {exc}")


# -----------------------------------------------------------------------------
# 10. Final vouching statement
# -----------------------------------------------------------------------------
# This is a short statement you can adapt for your presentation.

vouching_statement = f"""
Vouching statement
------------------
We cleaned the KS4 destinations data to the latest London local-authority slice and
removed duplicate/overlapping provision groups.  Because the dataset is aggregate
and not a direct NEET/unemployment dataset, we used 'Not recorded as a sustained
destination' as a proxy risk indicator, not as a confirmed unemployment label.

The model predicts whether a borough/subgroup combination sits in the top quartile
of this risk proxy, using only descriptive fields and cohort size.  We avoided
using other destination percentages as input features, because those would leak
information from the target.  We compared the model with a dummy baseline and used
a borough-grouped train/test split to test generalisation to unseen boroughs.

The model should be used for policy triage and discussion, not for individual-level
decisions.  The safest action is to combine the model rankings with local knowledge
from borough teams, schools, youth services, voluntary organisations, and young
people themselves.
""".strip()

(OUTPUT_DIR / "15_vouching_statement.txt").write_text(vouching_statement)
print("\n" + vouching_statement)
print("\nAll outputs saved in:", OUTPUT_DIR)
